const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

// Membuat RSA key pair untuk public key dan private key
const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
  modulusLength: 512,
  publicKeyEncoding: { type: "spki", format: "pem" },
  privateKeyEncoding: { type: "pkcs8", format: "pem" },
});

// Koneksi ke server
const socket = io("http://localhost:3000");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "> ",
});

let username = ""; // Username pengguna
let targetUsername = ""; // Target untuk secret chat
const users = new Map(); // Penyimpanan username dan public key

socket.on("connect", () => {
  console.log("Connected to the server");

  rl.question("Enter your username: ", (input) => {
    username = input;
    console.log(`Welcome, ${username}!`);

    socket.emit("registerPublicKey", { username, publicKey });
    rl.prompt();

    rl.on("line", handleInput); // Tangani input pengguna
  });
});

// Handle daftar client yang sudah ada
socket.on("init", (keys) => {
  keys.forEach(([user, key]) => users.set(user, key.publicKey));
  console.log(`\nCurrently ${users.size} users in the chat`);
  rl.prompt();
});

// Handle client baru
socket.on("newUser", ({ username, publicKey }) => {
  users.set(username, publicKey);
  console.log(`${username} joined the chat`);
  rl.prompt();
});

// Handle pesan biasa
socket.on("message", ({ username: sender, message }) => {
  if (sender !== username) {
    console.log(`${sender}: ${message}`);
  }
  rl.prompt();
});

// Handle pesan rahasia
socket.on("secretMessage", ({ sender, target, message }) => {
  if (target === username) {
    const decryptedMessage = decryptMessage(message);
    console.log(`[Secret from ${sender}]: ${decryptedMessage}`);
  } else {
    console.log(message); // Tampilkan ciphertext untuk penerima yang salah
  }
  rl.prompt();
});

// Handle client yang disconnect
socket.on("userDisconnected", ({ username }) => {
  users.delete(username);
  console.log(`${username} has left the chat.`);
  rl.prompt();
});

// Handle server disconnect
socket.on("disconnect", () => {
  console.log("Server disconnected. Exiting...");
  rl.close();
  process.exit(0);
});

// Handle Ctrl+C untuk keluar
rl.on("SIGINT", () => {
  console.log("\nExiting...");
  socket.disconnect();
  rl.close();
  process.exit(0);
});

// Fungsi untuk meng-handle input pengguna
function handleInput(message) {
  if (!message.trim()) return;

  if (message.startsWith("!secret")) {
    const [, target] = message.split(" ");
    if (target) {
      targetUsername = target;
      console.log(`Now secretly chatting with ${targetUsername}`);
    }
  } else if (message === "!exit") {
    console.log(`No longer secretly chatting with ${targetUsername}`);
    targetUsername = "";
  } else {
    if (targetUsername) {
      const encryptedMessage = encryptMessage(message, targetUsername);
      if (encryptedMessage) {
        socket.emit("secretMessage", {
          sender: username,
          target: targetUsername,
          message: encryptedMessage,
        });
      }
    } else {
      socket.emit("message", { username, message });
    }
  }
  rl.prompt();
}

// Fungsi untuk mengenkripsi pesan
function encryptMessage(message, target) {
  const targetPublicKey = users.get(target);
  if (!targetPublicKey) {
    console.error(`No public key found for ${target}. Ensure ${target} is connected.`);
    return null;
  }
  return crypto
    .publicEncrypt(targetPublicKey, Buffer.from(message))
    .toString("base64");
}

// Fungsi untuk mendekripsi pesan
function decryptMessage(encryptedMessage) {
  return crypto
    .privateDecrypt(privateKey, Buffer.from(encryptedMessage, "base64"))
    .toString("utf8");
}
