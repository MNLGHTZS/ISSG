const express = require('express'); // Framework untuk membuat server.
const session = require('express-session'); // Middleware untuk mengelola sesi pengguna.
const passport = require('passport'); // Library untuk otentikasi.
const GoogleStrategy = require('passport-google-oauth20').Strategy; // Strategi otentikasi Google OAuth 2.0.

const app = express(); // Inisialisasi aplikasi Express.

app.use(session({
    secret: 'secret-key', // Kunci rahasia untuk mengenkripsi data sesi.
    resave: false, // Tidak menyimpan sesi jika tidak ada perubahan.
    saveUninitialized: true // Menyimpan sesi meskipun tidak diubah.
}));

app.set('view engine', 'ejs'); // Menggunakan EJS sebagai engine untuk merender tampilan.

app.use(passport.initialize()); // Inisialisasi Passport.
app.use(passport.session()); // Menghubungkan Passport dengan sesi.

passport.use(
    new GoogleStrategy(
        {
            clientID: "", // ID aplikasi dari Google Cloud.
            clientSecret: "", // Secret aplikasi dari Google Cloud.
            callbackURL: "http://localhost:3000/auth/google/callback", // URL callback setelah login berhasil.
        }, 
        (accessToken, refreshToken, profile, done) => {
            // Callback ketika autentikasi berhasil.
            return done(null, profile); // Menyelesaikan autentikasi dengan mengembalikan profil pengguna.
        }
    )
);

passport.serializeUser((user, done) => {
    // Menentukan data pengguna yang disimpan di sesi.
    done(null, user); // Menyimpan seluruh profil pengguna di sesi.
});

passport.deserializeUser((obj, done) => {
    // Mengambil data pengguna dari sesi.
    done(null, obj); // Mengembalikan data pengguna untuk digunakan di aplikasi.
});

app.get('/', (req, res) => {
    // Route untuk halaman utama.
    res.render('index'); // Menampilkan file 'index.ejs'.
});

app.get('/auth/google',
    passport.authenticate('google', 
    {
        scope: ['profile', 'email'], // Meminta akses ke profil dan email pengguna.
        prompt: 'select_account' // Memaksa pengguna memilih akun jika memiliki banyak akun.
    })
);

app.get("/auth/google/callback", 
    passport.authenticate("google", { failureRedirect: "/" }), // Middleware untuk memproses callback dari Google.
    (req, res) => {
        res.redirect("/profile"); // Jika sukses, arahkan pengguna ke halaman profil.
    }
);

app.get("/profile", (req, res) => {
    // Route untuk halaman profil.
    if (!req.isAuthenticated()) { 
        // Jika pengguna belum login, arahkan mereka ke halaman login Google.
        return res.redirect("/auth/google");
    }
    res.render('profile', { user: req.user }); // Tampilkan file 'profile.ejs' dengan data pengguna.
});

app.get('/logout', (req, res) => {
    // Route untuk logout.
    req.logout(err => { 
        // Menghapus sesi pengguna.
        if (err) return next(err); // Jika ada error, lanjutkan ke handler error berikutnya.
        res.redirect('/'); // Arahkan kembali ke halaman utama setelah logout.
    });
});

app.listen(3000, () => {
    // Menjalankan server pada port 3000.
    console.log('server is running on port 3000'); // Log ke konsol bahwa server berjalan.
});